<?php
// delete_mesin.php
session_start();
require_once "config1.php"; // Include your DB config file


if (isset($_POST['id'])) {

  $id = $_POST['id'];
  echo $id;
  mysqli_query($koneksi,"DELETE FROM mesin_rfid where id_mesin = '$id'");
}

?>


