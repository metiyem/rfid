<?php
session_start();


if ($_SESSION['status'] != "login") {
    header("location:login.php");
}
require 'config1.php';  // Koneksi database

$user_id = $_SESSION['id'];

$sqlku = "SELECT company.id FROM company JOIN user ON user.id_company = company.id WHERE user.id = '$user_id'";

$resultku = mysqli_query($koneksi,$sqlku);
$resku    = mysqli_fetch_assoc($resultku);
$id_company = $resku['id']; // Pengaturan koneksi database

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT. Mantap - Manajemen Shift</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="../src/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="../src/css/sb-admin-2.min.css" rel="stylesheet">
    <script src="../src/vendor/jquery/jquery.min.js"></script>
    <script src="../src/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'partial_sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'partial_topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Manajemen Shift</h1>
                    <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#tambahShiftModal">Tambah Shift Baru</button>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Shift Tersedia</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nama Shift</th>
                                            <th>Jam Masuk</th>
                                            <th>Jam Keluar</th>
                                            <th>Hari Libur</th>
                                            <th>Toleransi Keterlambatan</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody id="shiftData">
                                        <!-- Data akan dimuat menggunakan AJAX -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copywrite text-center my-auto">
                            <span>Hak Cipta &copy; PT. Mantap 2021</span>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>

    <!-- Modal Tambah Shift -->
    <div class="modal fade" id="tambahShiftModal" tabindex="-1" role="dialog" aria-labelledby="tambahShiftModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tambahShiftModalLabel">Tambah Shift Baru</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="tambahShiftForm">
                        <div class="form-group">
                            <label for="shiftName">Nama Shift</label>
                            <input type="text" class="form-control" id="shiftName" name="nama_shift" required>
                        </div>
                        <div class="form-group">
                            <label for="shiftStart">Jam Masuk (HH:MM:SS)</label>
                            <input type="text"  class="form-control" id="shiftStart" name="jam_masuk" required>
                        </div>
                        <div class="form-group">
                            <label for="shiftEnd">Jam Keluar (HH:MM:SS)</label>
                            <input type="text"  class="form-control" id="shiftEnd" name="jam_keluar" required>
                        </div>
                        <div class="form-group">
                            <label for="shiftDaysOff">Hari Libur</label>
                            <input type="text" class="form-control" id="shiftDaysOff" name="libur" required>
                        </div>
                        <div class="form-group">
                            <label for="toleransiTerlambat">Toleransi Keterlambatan (HH:MM:SS)</label>
                            <input type="text"  class="form-control" id="toleransiTerlambat" name="toleransi_terlambat" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
    <!-- Modal Edit Shift -->
    <div class="modal fade" id="editShiftModal" tabindex="-1" role="dialog" aria-labelledby="editShiftModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editShiftModalLabel">Edit Shift</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editShiftForm">
                        <input type="hidden" id="editShiftId" name="id">
                        <div class="form-group">
                            <label for="editShiftName">Nama Shift</label>
                            <input type="text" class="form-control" id="editShiftName" name="nama_shift" required>
                        </div>
                        <div class="form-group">
                            <label for="editShiftStart">Jam Masuk (HH:MM:SS)</label>
                            <input type="text"  class="form-control" id="editShiftStart" name="jam_masuk" required>
                        </div>
                        <div class="form-group">
                            <label for="editShiftEnd">Jam Keluar (HH:MM:SS)</label>
                            <input type="text"  class="form-control" id="editShiftEnd" name="jam_keluar" required>
                        </div>
                        <div class="form-group">
                            <label for="editShiftDaysOff">Hari Libur</label>
                            <input type="text" class="form-control" id="editShiftDaysOff" name="libur" required>
                        </div>
                        <div class="form-group">
                            <label for="editToleransiTerlambat">Toleransi Keterlambatan (HH:MM:SS)</label>
                            <input type="text"  class="form-control" id="editToleransiTerlambat" name="toleransi_terlambat" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        // Memuat shift
        function loadShifts() {
            $.ajax({
                url: 'shift_action.php',
                type: 'POST',
                data: { action: 'read' },
                success: function(data) {
                    $('#shiftData').html(data);
                }
            });
        }

        loadShifts(); // Pemuatan awal

        // Menyimpan shift
        $('#tambahShiftForm').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                type: "POST",
                url: "tambah_shift.php",
                data: formData + '&id_company=<?php echo $id_company; ?>', // Mengirim id_company
                success: function(response) {
                    // console.log(response);
                    alert('Shift berhasil ditambahkan');
                    $('#tambahShiftModal').modal('hide');
                    loadShifts();
                },
                error: function() {
                    alert('Gagal menambahkan shift');
                }
            });
        });

        // Menghapus shift
        $(document).on('click', '.delete-btn', function() {
            var id = $(this).data('id');
            if (confirm('Apakah Anda yakin ingin menghapus shift ini?')) {
                $.ajax({
                    type: "POST",
                    url: "hapus_shift.php",
                    data: { id: id, action: 'delete' },
                    success: function(response) {
                        alert('Shift berhasil dihapus');
                        loadShifts();
                    },
                    error: function() {
                        alert('Gagal menghapus shift');
                    }
                });
            }
        });

        // Menyiapkan modal untuk edit shift
        $(document).on('click', '.edit-btn', function() {
            var id = $(this).data('id');
            $.ajax({
                type: "POST",
                url: "edit_shift.php",
                data: { id: id, action: 'get_single' },
                success: function(response) {
                    var data = JSON.parse(response);
                    $('#editShiftId').val(data.id);
                    $('#editShiftName').val(data.nama_shift);
                    $('#editShiftStart').val(data.jam_masuk);
                    $('#editShiftEnd').val(data.jam_keluar);
                    $('#editShiftDaysOff').val(data.libur);
                    $('#editToleransiTerlambat').val(data.toleransi_terlambat);
                    $('#editShiftModal').modal('show');
                },
                error: function() {
                    alert('Gagal memuat data shift');
                }
            });
        });

        // Menyimpan perubahan pada shift yang diedit
        $('#editShiftForm').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                type: "POST",
                url: "edit_shift.php",
                data: formData,
                success: function(response) {
                    alert('Shift berhasil diperbarui');
                    $('#editShiftModal').modal('hide');
                    loadShifts();
                },
                error: function() {
                    alert('Gagal memperbarui shift');
                }
            });
        });
    });
    </script>
</body>
</html>
