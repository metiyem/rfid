<?php
require_once "model.php";
$model = new Model("localhost", "root", "", "rfid", "mesin_rfid");

$requestMethod = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents("php://input"), true);

switch ($requestMethod) {
    case 'GET':
        echo json_encode($model->findAll());
        break;
    case 'POST':
        echo json_encode(['success' => $model->input($data)]);
        break;
    case 'PUT':
        echo json_encode(['success' => $model->edit($data['id'], $data)]);
        break;
    case 'DELETE':
        echo json_encode(['success' => $model->hapus($data['id'])]);
        break;
    default:
        header("HTTP/1.1 405 Method Not Allowed");
        break;
}
