#!/bin/bash

# Masuk ke direktori tempat file PHP Anda berada
cd /home/kali/kode/rfid/rfid1

# Mulai server PHP

* * * * * php /home/kali/kode/rfid/rfid1/cindex.php >> /home/kali/kode/rfid/rfid1/cron.log 2>&1
php -S localhost:8000