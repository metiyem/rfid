<?php
session_start();

if ($_SESSION['status'] != "login") {
    header("location:login.php");
}
require 'config1.php';  // Koneksi database

$user_id = $_SESSION['id'];
$nama_karyawan = $_GET['nama'];

// Query untuk mendapatkan detail rekap harian/mingguan dengan nama karyawan
$queryDetail = "
-- Query untuk mendapatkan detail rekap harian/mingguan dengan nama karyawan, null diganti dengan --, dan kolom mencerminkan minggu ke berapa dalam bulan
-- Query untuk mendapatkan detail rekap harian/mingguan dengan nama karyawan, null diganti dengan --, dan kolom mencerminkan minggu ke berapa dalam bulan
SELECT 
    k.nama AS Nama_Karyawan,
    DATE_FORMAT(a.tanggal, '%M') AS Bulan,
    FLOOR((DAY(a.tanggal) - 1) / 7) + 1 AS Mingguke,
    COALESCE(
        MAX(CASE WHEN DAYOFWEEK(a.tanggal) = 2 THEN
            CASE
                WHEN a.keterangan = 'tepat waktu' THEN 'Hadir'
                WHEN a.keterangan IN ('telat', 'alpha') THEN 'Tidak Hadir'
                WHEN a.keterangan = 'cuti' THEN 'Tidak Hadir (Cuti/Izin)'
                WHEN a.keterangan = 'libur' THEN 'Libur'
            END
        END), '--') AS Senin,
    COALESCE(
        MAX(CASE WHEN DAYOFWEEK(a.tanggal) = 3 THEN
            CASE
                WHEN a.keterangan = 'tepat waktu' THEN 'Hadir'
                WHEN a.keterangan IN ('telat', 'alpha') THEN 'Tidak Hadir'
                WHEN a.keterangan = 'cuti' THEN 'Tidak Hadir (Cuti/Izin)'
                WHEN a.keterangan = 'libur' THEN 'Libur'
            END
        END), '--') AS Selasa,
    COALESCE(
        MAX(CASE WHEN DAYOFWEEK(a.tanggal) = 4 THEN
            CASE
                WHEN a.keterangan = 'tepat waktu' THEN 'Hadir'
                WHEN a.keterangan IN ('telat', 'alpha') THEN 'Tidak Hadir'
                WHEN a.keterangan = 'cuti' THEN 'Tidak Hadir (Cuti/Izin)'
                WHEN a.keterangan = 'libur' THEN 'Libur'
            END
        END), '--') AS Rabu,
    COALESCE(
        MAX(CASE WHEN DAYOFWEEK(a.tanggal) = 5 THEN
            CASE
                WHEN a.keterangan = 'tepat waktu' THEN 'Hadir'
                WHEN a.keterangan IN ('telat', 'alpha') THEN 'Tidak Hadir'
                WHEN a.keterangan = 'cuti' THEN 'Tidak Hadir (Cuti/Izin)'
                WHEN a.keterangan = 'libur' THEN 'Libur'
            END
        END), '--') AS Kamis,
    COALESCE(
        MAX(CASE WHEN DAYOFWEEK(a.tanggal) = 6 THEN
            CASE
                WHEN a.keterangan = 'tepat waktu' THEN 'Hadir'
                WHEN a.keterangan IN ('telat', 'alpha') THEN 'Tidak Hadir'
                WHEN a.keterangan = 'cuti' THEN 'Tidak Hadir (Cuti/Izin)'
                WHEN a.keterangan = 'libur' THEN 'Libur'
            END
        END), '--') AS Jumat,
    COALESCE(
        MAX(CASE WHEN DAYOFWEEK(a.tanggal) = 7 THEN
            CASE
                WHEN a.keterangan = 'tepat waktu' THEN 'Hadir'
                WHEN a.keterangan IN ('telat', 'alpha') THEN 'Tidak Hadir'
                WHEN a.keterangan = 'cuti' THEN 'Tidak Hadir (Cuti/Izin)'
                WHEN a.keterangan = 'libur' THEN 'Libur'
            END
        END), '--') AS Sabtu,
    COALESCE(
        MAX(CASE WHEN DAYOFWEEK(a.tanggal) = 1 THEN
            CASE
                WHEN a.keterangan = 'tepat waktu' THEN 'Hadir'
                WHEN a.keterangan IN ('telat', 'alpha') THEN 'Tidak Hadir'
                WHEN a.keterangan = 'cuti' THEN 'Tidak Hadir (Cuti/Izin)'
                WHEN a.keterangan = 'libur' THEN 'Libur'
            END
        END), '--') AS Minggu
FROM
    absen a
INNER JOIN
    karyawan k ON a.uid = k.uid
INNER JOIN
    mesin_rfid mr ON a.id_mesin = mr.id_mesin
INNER JOIN
    company c ON mr.id_company = c.id
INNER JOIN
    user u ON c.id = u.id_company
WHERE
    u.id = '$user_id' and k.nama = '$nama_karyawan'
GROUP BY 
    k.nama, Bulan, Mingguke
ORDER BY 
    k.nama, a.tanggal;

";

// Eksekusi query detail
$resultDetail = mysqli_query($koneksi, $queryDetail);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT. Mantap - Detail Absensi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="../src/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="../src/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../src/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'partial_sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'partial_topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Detail Absensi</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Detail Absensi untuk <?php echo $nama_karyawan; ?></h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="detailTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Bulan</th>
                                            <th>Minggu</th>
                                            <th>Senin</th>
                                            <th>Selasa</th>
                                            <th>Rabu</th>
                                            <th>Kamis</th>
                                            <th>Jumat</th>
                                            <th>Sabtu</th>
                                            <th>Minggu</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        while ($row = mysqli_fetch_assoc($resultDetail)) {
                                            echo "<tr>";
                                            echo "<td>" . $row['Bulan'] . "</td>";
                                            echo "<td>" . $row['Mingguke'] . "</td>";
                                            echo "<td>" . $row['Senin'] . "</td>";
                                            echo "<td>" . $row['Selasa'] . "</td>";
                                            echo "<td>" . $row['Rabu'] . "</td>";
                                            echo "<td>" . $row['Kamis'] . "</td>";
                                            echo "<td>" . $row['Jumat'] . "</td>";
                                            echo "<td>" . $row['Sabtu'] . "</td>";
                                            echo "<td>" . $row['Minggu'] . "</td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copywrite text-center my-auto">
                            <span>Hak Cipta &copy; PT. Mantap 2021</span>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
    <script src="../src/vendor/jquery/jquery.min.js"></script>
    <script src="../src/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../src/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../src/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.flash.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#detailTable').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'csvHtml5',
                        className: 'btn btn-info btn-sm',
                        text: '<i class="fas fa-file-csv"></i> Export CSV',
                        titleAttr: 'CSV export',
                        exportOptions: {
                            columns: ':visible' // Export only visible columns
                        }
                    }
                ]
            });
        });
    </script>
</body>
</html>
