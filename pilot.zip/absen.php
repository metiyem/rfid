<?php
session_start();

if ($_SESSION['status'] != "login") {
    header("location:login.php");
}
require 'config1.php';  // Koneksi database

$user_id = $_SESSION['id'];

// Query untuk mendapatkan ringkasan rekap bulanan dengan nama karyawan
$querySummary = "
SELECT 
    k.nama AS Nama_Karyawan,
    DATE_FORMAT(a.tanggal, '%M') AS Bulan,
    COUNT(CASE WHEN a.keterangan = 'tepat waktu' THEN 1 END) AS Masuk,
    COUNT(CASE WHEN a.keterangan IN ('alpha', 'libur') THEN 1 END) AS Tidak_Masuk,
    COUNT(CASE WHEN a.keterangan = 'cuti' THEN 1 END) AS Cuti_Izin,
    COUNT(CASE WHEN a.keterangan = 'libur' THEN 1 END) AS Libur
FROM
    absen a
INNER JOIN
    karyawan k ON a.uid = k.uid
INNER JOIN
    mesin_rfid mr ON a.id_mesin = mr.id_mesin
INNER JOIN
    company c ON mr.id_company = c.id
INNER JOIN
    user u ON c.id = u.id_company
WHERE
    u.id = '$user_id'
GROUP BY 
    k.nama, Bulan;
";

// Eksekusi query summary
$resultSummary = mysqli_query($koneksi, $querySummary);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT. Mantap - Ringkasan Bulanan Absensi</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="../src/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="../src/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../src/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
      <style>
        .buttons-csv {
            color: #fff;
            background-color: #28a745;
            border-color: #28a745;
            margin-right: 5px;
        }
        .buttons-csv:hover {
            color: #fff;
            background-color: #218838;
            border-color: #1e7e34;
        }
    </style>
    <script src="../src/vendor/jquery/jquery.min.js"></script>
    <script src="../src/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../src/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../src/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'partial_sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'partial_topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Ringkasan Bulanan Absensi</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Ringkasan Bulanan</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="summaryTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Nama Karyawan</th>
                                            <th>Bulan</th>
                                            <th>Masuk</th>
                                            <th>Tidak Masuk</th>
                                            <th>Cuti/Izin</th>
                                            <th>Libur</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        while ($row = mysqli_fetch_assoc($resultSummary)) {
                                            echo "<tr>";
                                            echo "<td><a href='detail_absensi.php?nama=" . urlencode($row['Nama_Karyawan']) . "'>" . $row['Nama_Karyawan'] . "</a></td>";
                                            echo "<td>" . $row['Bulan'] . "</td>";
                                            echo "<td>" . $row['Masuk'] . "</td>";
                                            echo "<td>" . $row['Tidak_Masuk'] . "</td>";
                                            echo "<td>" . $row['Cuti_Izin'] . "</td>";
                                            echo "<td>" . $row['Libur'] . "</td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copywrite text-center my-auto">
                            <span>Hak Cipta &copy; PT. Mantap 2021</span>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
    <script>
         $(document).ready(function() {
            $('#summaryTable').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'csvHtml5',
                        className: 'buttons-csv btn btn-primary',
                        text: '<i class="fas fa-file-csv"></i> Export CSV',
                        titleAttr: 'Export CSV'
                    }
                ]
            });
        });
    </script>
</body>
</html>
