<?php
session_start();
require 'config1.php';  // Database connection

$action = $_POST['action'] ?? '';
$company_id = $_SESSION['company_id'];
echo $company_id;
switch ($action) {
    case 'read':
        // Mengambil semua data shift
        $query = "SELECT * FROM shift where id_company = '$company_id'" ;
        $result = mysqli_query($koneksi, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['nama_shift']}</td>
                    <td>{$row['jam_masuk']}</td>
                    <td>{$row['jam_keluar']}</td>
                    <td>{$row['libur']}</td>
                    <td>{$row['toleransi_terlambat']}</td>
                    <td>
                        <button class='btn btn-info btn-circle btn-sm edit-btn' data-id='{$row['id']}'><i class='fas fa-edit'></i></button>
                        <button class='btn btn-danger btn-circle btn-sm delete-btn' data-id='{$row['id']}'><i class='fas fa-trash'></i></button>
                    </td>
                </tr>";
        }
        break;

    }
?>
