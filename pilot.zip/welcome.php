<?php
session_start();

// Cek login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: super_admin.php');
    exit;
}

require_once 'config1.php'; // File konfigurasi database

// Menangani POST request untuk membuat user baru
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $id_company = $_POST['company'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash password

    $sql = "INSERT INTO user (email, password, id_company) VALUES (?, ?, ?)";
    
    if ($stmt = mysqli_prepare($koneksi, $sql)) {
        mysqli_stmt_bind_param($stmt, "ssi", $email, $hashed_password, $id_company);
        
        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('User berhasil ditambahkan');</script>";
        } else {
            echo "<script>alert('Terjadi kesalahan. Silakan coba lagi');</script>";
        }
        mysqli_stmt_close($stmt);
    }
}

// Mengambil daftar perusahaan untuk dropdown
$companies = [];
$sql = "SELECT id, nama_company FROM company";
if ($result = mysqli_query($koneksi, $sql)) {
    while ($row = mysqli_fetch_assoc($result)) {
        $companies[] = $row;
    }
    mysqli_free_result($result);
}

mysqli_close($koneksi);

include 'partial_top_s.php'; // Memuat top bar
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Page</title>
    <link href="../src/css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h1 class="mt-5">Tambah User Baru</h1>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="company">Perusahaan</label>
            <select class="form-control" id="company" name="company">
                <?php foreach ($companies as $company): ?>
                    <option value="<?php echo $company['id']; ?>"><?php echo $company['nama_company']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Tambah</button>
    </form>
</div>

<script src="../src/vendor/jquery/jquery.min.js"></script>
<script src="../src/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
