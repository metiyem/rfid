<?php
session_start();

if ($_SESSION['status'] != "login") {
    header("location:login.php");
}
require 'config1.php';  // Koneksi database

$user_id = $_SESSION['id'];
$id_company = $_SESSION['company_id'];  // Asumsi ini diset saat login

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_devisi = $_POST['nama_devisi'];
    $id_devisi = $_POST['id'] ?? null;

    switch ($_POST['action']) {
        case 'create':
            $insertQuery = "INSERT INTO devisi (nama_devisi, id_company) VALUES ('$nama_devisi', '$id_company')";
            mysqli_query($koneksi, $insertQuery);
            break;
        case 'update':
            $updateQuery = "UPDATE devisi SET nama_devisi='$nama_devisi' WHERE id='$id_devisi' AND id_company='$id_company'";
            mysqli_query($koneksi, $updateQuery);
            break;
        case 'delete':
            $deleteQuery = "DELETE FROM devisi WHERE id='$id_devisi' AND id_company='$id_company'";
            mysqli_query($koneksi, $deleteQuery);
            break;
    }
}

$devisiQuery = "SELECT * FROM devisi WHERE id_company='$id_company'";
$devisiResult = mysqli_query($koneksi, $devisiQuery);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT. Mantap - Manajemen Devisi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="../src/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="../src/css/sb-admin-2.min.css" rel="stylesheet">
    <script src="../src/vendor/jquery/jquery.min.js"></script>
    <script src="../src/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'partial_sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'partial_topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Manajemen Devisi</h1>
                    <!-- Modal untuk tambah dan edit -->
                    <!-- Modal Tambah Devisi -->
<div class="modal fade" id="tambahDevisiModal" tabindex="-1" role="dialog" aria-labelledby="tambahDevisiModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahDevisiModalLabel">Tambah Devisi Baru</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="tambahDevisiForm" method="POST">
                    <div class="form-group">
                        <label for="devisiName">Nama Devisi</label>
                        <input type="text" class="form-control" id="devisiName" name="nama_devisi" required>
                    </div>
                    <input type="hidden" name="action" value="create">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

                    <!-- Modal Edit Devisi -->
<div class="modal fade" id="editDevisiModal" tabindex="-1" role="dialog" aria-labelledby="editDevisiModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editDevisiModalLabel">Edit Devisi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="editDevisiForm" method="POST">
                    <input type="hidden" id="editDevisiId" name="id">
                    <div class="form-group">
                        <label for="editDevisiName">Nama Devisi</label>
                        <input type="text" class="form-control" id="editDevisiName" name="nama_devisi" required>
                    </div>
                    <input type="hidden" name="action" value="update">
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </form>
            </div>
        </div>
    </div>
</div>

                    <!-- Include modals here -->
                    <!-- Tombol untuk membuka modal Tambah Devisi -->
<button class="btn btn-primary mb-3" data-toggle="modal" data-target="#tambahDevisiModal">Tambah Devisi Baru</button>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Daftar Devisi</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Devisi</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $no = 1;while ($row = mysqli_fetch_assoc($devisiResult)): ?>
                                            <tr>
                                                <td><?= $no ++ ?></td>
                                                <td><?= $row['nama_devisi']; ?></td>
                                                <td>
                                                    <button class="btn btn-info btn-circle btn-sm edit-btn" data-id="<?= $row['id']; ?>" data-nama="<?= $row['nama_devisi']; ?>"><i class="fas fa-edit"></i></button>
                                                    <button class="btn btn-danger btn-circle btn-sm delete-btn" data-id="<?= $row['id']; ?>"><i class="fas fa-trash"></i></button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copywrite text-center my-auto">
                            <span>Hak Cipta &copy; PT. Mantap 2021</span>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
    <script>
    $(document).ready(function() {
        // Menginisiasi modal edit
        $('.edit-btn').click(function() {
            var id = $(this).data('id');
            var nama = $(this).data('nama');

            $('#editDevisiId').val(id);
            $('#editDevisiName').val(nama);

            $('#editDevisiModal').modal('show');
        });

        // Menangani form submit tambah
        $('#tambahDevisiForm').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            $.post(window.location.href, formData, function(data) {
                $('#tambahDevisiModal').modal('hide');
                location.reload(); // refresh halaman untuk memperbarui data tabel
            });
        });

        // Menangani form submit edit
        $('#editDevisiForm').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            $.post(window.location.href, formData, function(data) {
                $('#editDevisiModal').modal('hide');
                location.reload(); // refresh halaman untuk memperbarui data tabel
            });
        });

        // Menangani tombol hapus
        $('.delete-btn').click(function() {
            var id = $(this).data('id');
            if (confirm('Apakah Anda yakin ingin menghapus data ini?')) {
                $.post(window.location.href, { action: 'delete', id: id }, function(data) {
                    location.reload(); // refresh halaman untuk memperbarui data tabel
                });
            }
        });
    });
</script>

</body>
</html>
