<?php
session_start();

if ($_SESSION['status'] != "login") {
    header("location:login.php");
}

require 'config1.php';  // Koneksi database
$user_id = $_SESSION['id'];
$id_c = $_SESSION['company_id']; 
 // Sesuaikan dengan ID company yang diinginkan

$query = "SELECT p.uid
          FROM penampung p
          JOIN mesin_rfid m ON p.id_mesin = m.id_mesin
          WHERE m.id_company = '$id_c'";

$result = mysqli_query($koneksi, $query);

$uid_c = ''; // Inisialisasi default uid
if ($row = mysqli_fetch_assoc($result)) {
    $uid_c = $row['uid'];
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $uid = $_POST['uid'] ?? '';
    $nama = $_POST['nama'];
    $devisi = $_POST['devisi'];
    $shift = $_POST['shift'];
    $mulai_kerja = $_POST['mulai_kerja'];
    $cuti_sampai = !empty($_POST['cuti_sampai']) ? $_POST['cuti_sampai'] : NULL;  // Cek apakah field cuti sampai diisi

    switch ($_POST['action']) {
        case 'create':
            $devisi =intval($devisi);
            $insertQuery = "INSERT INTO karyawan (uid, nama, devisi, shift, mulai_kerja, cuti_sampai, id_company) VALUES ('$uid', '$nama', $devisi, '$shift', '$mulai_kerja', NULL, (SELECT id_company FROM user WHERE id='$user_id'))";
            mysqli_query($koneksi, $insertQuery);
            break;
        case 'update':
           $stmt = $koneksi->prepare("UPDATE karyawan SET nama=?, devisi=?, shift=?, mulai_kerja=?, cuti_sampai=? WHERE uid=?");
        $stmt->bind_param("siissi", $nama, $devisi, $shift, $mulai_kerja, $cuti_sampai, $uid);
        $stmt->execute();
            break;
        // case 'delete':
        //     $uid = $_GET['id'];
        //     $deleteQuery = "DELETE FROM karyawan WHERE uid='$uid'";
        //     mysqli_query($koneksi, $deleteQuery);
        //     break;
    }
}

$karyawanQuery = "SELECT k.*, d.nama_devisi, s.nama_shift 
FROM karyawan k 
JOIN devisi d ON k.devisi = d.id 
JOIN shift s ON k.shift = s.id  -- Asumsi ada kolom 'shift' di tabel karyawan yang mereferensikan id di tabel shift
WHERE k.id_company = '$user_id'; ";
$karyawanResult = mysqli_query($koneksi, $karyawanQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT. Mantap - Manajemen Karyawan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="../src/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="../src/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../src/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'partial_sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'partial_topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Manajemen Karyawan</h1>
                    <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#addModal">Tambah Karyawan Baru</button>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Daftar Karyawan</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>UID</th>
                                            <th>Nama</th>
                                            <th>Devisi</th>
                                            <th>Shift</th>
                                            <th>Mulai Kerja</th>
                                            <th>Cuti Sampai</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $num = 1; ?>
                                        <?php while ($row = mysqli_fetch_assoc($karyawanResult)): ?>
                                            <tr>
                                                <td><?= $num++; ?></td>
                                                <td><?= htmlspecialchars($row['uid']); ?></td>
                                                <td><?= htmlspecialchars($row['nama']); ?></td>
                                                <td><?= htmlspecialchars($row['nama_devisi']); ?></td>
                                                <td><?= htmlspecialchars($row['nama_shift']); ?></td>
                                                <td><?= htmlspecialchars($row['mulai_kerja']); ?></td>
                                                <td><?= $row['cuti_sampai'] ? htmlspecialchars($row['cuti_sampai']) : '--'; ?></td>
                                                <td>
                                                    <button class="btn btn-info btn-circle btn-sm" onclick="editKaryawan('<?= $row['uid']; ?>', '<?= addslashes($row['nama']); ?>', '<?= $row['devisi']; ?>', '<?= $row['shift']; ?>', '<?= $row['mulai_kerja']; ?>', '<?= $row['cuti_sampai']; ?>')"><i class="fas fa-edit"></i></button>
                                                    <a href='del_kar.php?id=<?= $row['uid']; ?>' class="btn btn-danger btn-circle btn-sm"  ><i class="fas fa-trash"></i></a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copywrite text-center my-auto">
                            <span>Hak Cipta &copy; PT. Mantap 2021</span>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Karyawan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="create">
  

<div class="form-group">
    <label for="uid">UID</label>
    <input type="text" class="form-control" id="uid" name="uid" value="<?= htmlspecialchars($uid_c); ?>" required>
</div>

                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control" id="nama" name="nama" required>
                        </div>
                        <div class="form-group">
                            <label for="devisi">Devisi</label>
                           <?php
// Fetching devisi for the logged-in user's company
$devisiQuery = "SELECT id, nama_devisi FROM devisi WHERE id_company = (SELECT id_company FROM user WHERE id='$user_id')";
$devisiResult = mysqli_query($koneksi, $devisiQuery);
?>

<select class="form-control" id="devisi" name="devisi">
    <?php while ($devisi = mysqli_fetch_assoc($devisiResult)): ?>
        <option value="<?= $devisi['id']; ?>"><?= $devisi['nama_devisi']; ?></option>
    <?php endwhile; ?>
</select>

                        </div>
                        <div class="form-group">
                            <label for="shift">Shift</label>
                           Copy code
<?php
// Fetching shifts for the logged-in user's company
$shiftQuery = "SELECT id, nama_shift FROM shift WHERE id_company = (SELECT id_company FROM user WHERE id='$user_id')";
$shiftResult = mysqli_query($koneksi, $shiftQuery);
?>

<select class="form-control" id="shift" name="shift">
    <?php while ($shift = mysqli_fetch_assoc($shiftResult)): ?>
        <option value="<?= $shift['id']; ?>"><?= $shift['nama_shift']; ?></option>
    <?php endwhile; ?>
</select>
                        </div>
                        <div class="form-group">
                            <label for="mulai_kerja">Mulai Kerja</label>
                            <input type="date" class="form-control" id="mulai_kerja" name="mulai_kerja" required>
                        </div>
                       
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Karyawan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" id="edit_uid" name="uid">
                        <div class="form-group">
                            <label for="edit_nama">Nama</label>
                            <input type="text" class="form-control" id="edit_nama" name="nama" required>
                        </div>
                        <?php
// Fetch devisi options
$devisiQuery = "SELECT id, nama_devisi FROM devisi WHERE id_company = (SELECT id_company FROM user WHERE id='$user_id')";
$devisiResult = mysqli_query($koneksi, $devisiQuery);

// Fetch shift options
$shiftQuery = "SELECT id, nama_shift FROM shift WHERE id_company = (SELECT id_company FROM user WHERE id='$user_id')";
$shiftResult = mysqli_query($koneksi, $shiftQuery);
?>

                        <!-- Devisi Select in the Edit Modal -->
<div class="form-group">
    <label for="edit_devisi">Devisi</label>
    <select class="form-control" id="edit_devisi" name="devisi">
        <?php while ($devisi = mysqli_fetch_assoc($devisiResult)): ?>
            <option value="<?= $devisi['id']; ?>"><?= htmlspecialchars($devisi['nama_devisi']); ?></option>
        <?php endwhile; ?>
    </select>
</div>

<!-- Shift Select in the Edit Modal -->
<div class="form-group">
    <label for="edit_shift">Shift</label>
    <select class="form-control" id="edit_shift" name="shift">
        <?php while ($shift = mysqli_fetch_assoc($shiftResult)): ?>
            <option value="<?= $shift['id']; ?>"><?= htmlspecialchars($shift['nama_shift']); ?></option>
        <?php endwhile; ?>
    </select>
</div>

                        <div class="form-group">
                            <label for="edit_mulai_kerja">Mulai Kerja</label>
                            <input type="date" class="form-control" id="edit_mulai_kerja" name="mulai_kerja" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_cuti_sampai">Cuti Sampai</label>
                            <input type="date" class="form-control" id="edit_cuti_sampai" name="cuti_sampai">
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
    <script src="../src/vendor/jquery/jquery.min.js"></script>
    <script src="../src/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../src/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../src/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'csvHtml5',
                        className: 'buttons-csv btn btn-primary',
                        text: '<i class="fas fa-file-csv"></i> Export CSV',
                        titleAttr: 'Export CSV'
                    }
                ]
            });
        });

        function editKaryawan(uid, nama, devisi, shift, mulai_kerja, cuti_sampai) {
            $('#edit_uid').val(uid);
            $('#edit_nama').val(nama);
            $('#edit_devisi').val(devisi);
            $('#edit_shift').val(shift);
            $('#edit_mulai_kerja').val(mulai_kerja);
            $('#edit_cuti_sampai').val(cuti_sampai || '');
            $('#editModal').modal('show');
        }

        function deleteKaryawan(uid) {
            if (confirm('Are you sure you want to delete this karyawan?')) {
                $.post('karyawan.php', { action: 'delete', uid: uid }, function() {
                    window.location.reload();
                });
            }
        }
    </script>
</body>
</html>
