<?php
// update_mesin.php
var_dump($_POST)
?>

