<?php 
 $link = mysqli_connect('kali.kali', 'root', '', 'absensi'); 
$db_server = 'kali.kali'; 
$db_name = 'absensi'; 
$db_user = 'root'; 
$db_password = ''; 
?>