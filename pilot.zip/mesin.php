<?php
session_start();

if($_SESSION['status'] != "login"){
	header("location:login.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>PT. Mantap - Mesin RFID</title>

  <!-- Custom fonts for this template-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="../src/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../src/css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Bootstrap core JavaScript-->
  <script src="../src/vendor/jquery/jquery.min.js"></script>
  <script src="../src/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php include 'partial_sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php include 'partial_topbar.php'; ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Mesin RFID</h1>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Daftar Mesin RFID</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <?php
                require_once "config1.php"; // Database connection setup
                
                $user_id = $_SESSION['id'];
                $pageno = $_GET['pageno'] ?? 1;
                $no_of_records_per_page = 10;
                $offset = ($pageno - 1) * $no_of_records_per_page;
                $total_pages_sql = "SELECT COUNT(*) FROM mesin_rfid 
                    JOIN company ON mesin_rfid.id_company = company.id 
                    JOIN user ON company.id = user.id_company 
                    WHERE user.id = '$user_id'";
                $result = mysqli_query($koneksi, $total_pages_sql);
                $total_rows = mysqli_fetch_array($result)[0];
                $total_pages = ceil($total_rows / $no_of_records_per_page);

                $sql = "SELECT mesin_rfid.id_mesin, company.nama_company,company.id as comp_id FROM mesin_rfid 
                        JOIN company ON mesin_rfid.id_company = company.id 
                        JOIN user ON company.id = user.id_company 
                        WHERE user.id = '$user_id' 
                        LIMIT $offset, $no_of_records_per_page";
        if ($result = mysqli_query($koneksi, $sql)) {
          
    echo "<div class='mb-4'>";
echo "<a href='#' class='btn btn-success btn-icon-split' data-toggle='modal' data-target='#addMachineModal' ><span class='icon text-white-50'><i class='fas fa-plus'></i></span><span class='text'>Tambah Mesin</span></a>";
    echo "</div>";
    if (mysqli_num_rows($result) > 0) {
        echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>ID Mesin</th>";
        echo "<th>Nama Perusahaan</th>";
        echo "<th>Aksi</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['id_mesin']) . "</td>";
            echo "<td>" . htmlspecialchars($row['nama_company']) . "</td>";
            echo "<td>";
            $nama_compamy= $row['nama_company']; 
            $id_com= $row['comp_id']; 
            $i = $row['id_mesin'];
            // echo "<button class='btn btn-info btn-circle btn-sm' title='Edit' data-id='$id'><i class='fas fa-edit'></i></button> ";
            echo "<button class='btn btn-danger btn-circle btn-sm delete_s' title='Delete' data-id='$i'><i class='fas fa-trash'></i></button>";
            echo "</td>";
            echo "</tr>";
             echo "<div hidden id='t_mesin' data-id='$id_com'></div>";
        }
        echo "</tbody>";
        echo "</table>";
       
       
        mysqli_free_result($result);
    } else {
        echo "<p class='lead'><em>No records were found.</em></p>";
    }
} else {
    echo "ERROR: Could not execute $sql. " . mysqli_error($koneksi);
}
  
?>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Arducoding 2021</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
<!-- Modal Tambah Mesin -->
<div class="modal fade" id="addMachineModal" tabindex="-1" role="dialog" aria-labelledby="addMachineModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addMachineModalLabel" >Tambah Mesin Baru</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="addMachineForm">
          <div class="form-group">
            <label for="id_mesin">ID Mesin</label>
            <input type="text" class="form-control" id="id_mesin" name="id_mesin" required>
          </div>
     
          <button type="submit" class="btn btn-primary" id="tambah" data-user_id="<?= $user_id ?>" >Tambah</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal Edit Mesin -->
<!-- <div class="modal fade" id="editMachineModal" tabindex="-1" role="dialog" aria-labelledby="editMachineModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editMachineModalLabel">Edit Mesin</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="editMachineForm" action='' method='POST' >
          <div class="form-group">
            <label for="editMachineId">ID Mesin</label>
            <input type="text" class="form-control" id="editMachineId" name="id_mesin" required>
          </div>
          <div class="form-group">
            <label for="editCompanyName">Nama Perusahaan</label>
            <input type="text" class="form-control" id="editCompanyName" name="id_company" required>
          </div>
          <input type="submit" class="btn btn-primary" name="edit_s">
        </form>
      </div>
    </div>
  </div>
</div> -->

  <!-- Page level custom scripts -->
  <script src="../src/js/sb-admin-2.min.js"></script>
<script>
$(document).ready(function() {
  var id_com = $("#t_mesin").data("id");
    // Tambah Mesin
    $('#addMachineForm').submit(function(e) {
        e.preventDefault();
        var test = $("#id_mesin").val()
        t = {id_mesin:test,id_company:id_com}
        $.ajax({
            type: "POST",
            url: "tambah_mesin.php",
            data: t,
            success: function(response) {
                alert('Mesin berhasil ditambahkan');
                location.reload();
            },
            error: function() {
                alert('Gagal menambahkan mesin');
            }
        });
    });

    // Setup form modal untuk edit saat tombol edit diklik
    $('.btn-info').click(function() {
        var id = $(this).data('id');
        // Load data mesin ke dalam form edit
        $('#editMachineId').val(id);
        $('#editCompanyName').val($(this).closest('tr').find('td:eq(1)').text());
        $('#editMachineModal').modal('show');
    });

    $('.delete_s').on("click", function () {
       var id = $(this).data('id');
      console.log(id);
       $.ajax({
        type: "POST",
        url: "delete_mesin.php",
        data: {id:id},
        dataType: "JSON",
        success: function (response) {
          console.log(response);
          location.reload()
        }
       });
    });
  
});
</script>


<!-- <?php
// if (isset($_POST['edit_s'])) {

//   $id = $_POST['id_mesin'];
//   mysqli_query($koneksi,"UPDATE mesin_rfid set id_mesin = '$id' id_company = '$nama_company' where id_mesin = $id ");
// }

?> -->

</body>

</html>
