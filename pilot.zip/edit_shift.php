<?php
require_once "config1.php";
session_start();
if (isset($_POST['action']) and $_POST['action'] == 'get_single') {
     $id = $_POST['id'];
        $query = "SELECT * FROM shift WHERE id='$id'";
        $result = mysqli_query($koneksi, $query);
        $data = mysqli_fetch_assoc($result);
        echo json_encode($data);
}
else {
    $_SESSION['id'];

   $id = $_POST['id'];
        $nama_shift = $_POST['nama_shift'];
        $jam_masuk = $_POST['jam_masuk'];
        $jam_keluar = $_POST['jam_keluar'];
        $libur = $_POST['libur'];
        $toleransi_terlambat = $_POST['toleransi_terlambat'];
        $id_company = intval($_SESSION['id_company']);
        $query = "UPDATE shift SET nama_shift='$nama_shift', jam_masuk='$jam_masuk', jam_keluar='$jam_keluar', libur='$libur', toleransi_terlambat='$toleransi_terlambat',id_company='$id_company' WHERE id='$id'";
        mysqli_query($koneksi, $query);
}