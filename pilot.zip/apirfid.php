<?php
date_default_timezone_set('Asia/Jakarta');

function handleGETRequest()
{
    $tgl = date_create()->format("Y:m:d");
    $host = 'kali.kali';
    $user = 'root';
    $pw = '';
    $db = 'rfid';

    $koneksi = mysqli_connect($host, $user, $pw, $db);
    if (!$koneksi) {
        http_response_code(500);
        die(json_encode(array("message" => "Error koneksi ke database")));
    }

    $uid_a = mysqli_query($koneksi, "SELECT uid FROM karyawan");

    while ($res_uid_a = mysqli_fetch_assoc($uid_a)) {
        $uid_kar = $res_uid_a['uid'];
        $hari_sekarang = date_format(date_create(), 'l');
        echo $tgl;
        $absen = mysqli_query($koneksi, "SELECT karyawan.uid,shift.libur,shift.jam_masuk,shift.jam_keluar,shift.id_company,karyawan.cuti_sampai,karyawan.mulai_kerja,shift.toleransi_terlambat FROM shift JOIN karyawan ON shift.id = karyawan.shift WHERE karyawan.uid = '$uid_kar' AND shift.libur != '$hari_sekarang'");
       $libur_row = mysqli_fetch_assoc($absen);
        $tol = date_create($libur_row['jam_masuk']);
        $menit = $libur_row['toleransi_terlambat'];
        var_dump($libur_row);
        list($jam, $menit, $detik) = explode(':', $menit);
        $toleransi = date_modify($tol, "+$jam hours");
        $toleransi = date_modify($tol, "+$menit minutes");
        $toleransi = date_modify($tol, "+$detik seconds");
        if (mysqli_num_rows($absen) < 1 and date_create() > $toleransi) {
            $masuk = date_create()->format('H:i:s');
            mysqli_query($koneksi, "insert into absen values(NULL,'$uid_kar','$tgl',NULL,'alpha',NULL,NULL)");
            echo "alpha";
        }
        else {
            $libur_row = mysqli_fetch_assoc($absen);
            $libur = $libur_row['libur'];
            $hari_now = date_format(date_create(), 'l');
            if ($hari_now == $libur) {

                $tanggal = date_create()->format('Y-m-d');
                
                mysqli_query($koneksi, "INSERT INTO absen (uid, tanggal, status, id_mesin) VALUES ('$uid_kar', '$tanggal', 'libur', NULL)");
                echo "libur";
            }
            $cuti_sampai = $libur_row['cuti_sampai'];
            if (!empty($cuti_sampai) && date_create() <= date_create($cuti_sampai)) {
                $tanggal = date_create()->format('Y-m-d');
            
                mysqli_query($koneksi, "INSERT INTO absen (uid, tanggal, status, id_mesin) VALUES ('$uid_kar', '$tanggal', 'cuti', NULL)");
                echo "cuti";
            }

        }
    }
}


// Fungsi untuk menangani POST request
function handlePOSTRequest()
{
    $inputJSON = file_get_contents('php://input');
    $input = json_decode($inputJSON, true);

    if (isset($input['id_mesin']) && isset($input['uid'])) {
        $id_mesin = $input['id_mesin'];
        $uid = $input['uid'];

        // Validasi input ID Mesin dan UID
        if (!preg_match("/^[a-zA-Z0-9]+$/", $id_mesin)) {
            http_response_code(400);
            die(json_encode(array("message" => "Error: data ID Mesin anda tidak valid")));
        }
        if (!preg_match("/^[a-zA-Z0-9]+$/", $uid)) {
            http_response_code(400);
            die(json_encode(array("message" => "Error: Data UID anda tidak valid")));
        }

        $host = 'kali.kali';
        $user = 'root';
        $pw = '';
        $db = 'rfid';

        $koneksi = mysqli_connect($host, $user, $pw, $db);
        if (!$koneksi) {
            http_response_code(500);
            die(json_encode(array("message" => "Error koneksi ke database")));
        }
        
        $res_mesin = mysqli_query($koneksi, "SELECT mesin_rfid.id_mesin,mesin_rfid.id_company,company.id FROM mesin_rfid JOIN company ON mesin_rfid.id_company = company.id where mesin_rfid.id_mesin = $id_mesin");
        $res_uid = mysqli_query($koneksi, "select uid from karyawan where uid = '$uid'");
        $res_penampung = mysqli_query($koneksi, "select * from penampung where id_mesin = '$id_mesin'");
        $r_karyawan_shift = mysqli_query($koneksi, "SELECT karyawan.uid,shift.libur,shift.jam_masuk,shift.jam_keluar,shift.id_company,karyawan.cuti_sampai,karyawan.mulai_kerja,shift.toleransi_terlambat FROM shift JOIN karyawan ON shift.id = karyawan.shift WHERE karyawan.uid = '$uid'");

        if (mysqli_num_rows($res_mesin) == 1) {
            if (mysqli_num_rows($res_uid) == 1) {
                $karyawan = mysqli_fetch_assoc($r_karyawan_shift);
                $libur = $karyawan['libur'];
                $hari_now = date_format(date_create(), 'l');
                $now = date_create();

                if ($now > date_create($karyawan['mulai_kerja'])) {
                    if ($hari_now == $libur) {
                        $tanggal = date_create()->format('Y:m:d');
                        mysqli_query($koneksi, "insert into absen values(NULL,'$uid','$tanggal',NULL,'libur',NULL,'$id_mesin')");
                        http_response_code(201);
                        echo json_encode(array("message" => "Hari ini libur"));
                    } else {
                        if (empty($karyawan['cuti_sampai']) or $now > date_create($karyawan['cuti_sampai'])) {
                            $u_id = $karyawan['uid'];
                            $tanggal = date_create()->format('Y:m:d');

                            $ab_sen = mysqli_query($koneksi, "select * from absen where uid = '$u_id' and tanggal = '$tanggal'");
                            if (mysqli_num_rows($ab_sen) > 0) {
                                http_response_code(200);
                                echo json_encode(array("message" => "Anda sudah absen"));

                            }
                            else {
                            
                            if ($now >= date_create($karyawan['jam_masuk'])) {
                                if ($now > date_create($karyawan['jam_masuk'])) {
                                    $tol = date_create($karyawan['jam_masuk']);
                                    $menit = $karyawan['toleransi_terlambat'];
                                    list($jam, $menit, $detik) = explode(':', $menit);
                                    $toleransi = date_modify($tol, "+$jam hours");
                                    $toleransi = date_modify($tol, "+$menit minutes");
                                    $toleransi = date_modify($tol, "+$detik seconds");

                                    if (date_create() > $toleransi) {
                                        $masuk = date_create()->format('H:i:s');
                                        $tanggal = date_create()->format('Y:m:d');
                                        mysqli_query($koneksi, "insert into absen values(NULL,'$uid','$tanggal',NULL,'alpha',NULL,'$id_mesin')");
                                        http_response_code(201);
                                        echo json_encode(array("message" => "Alpha karena telat"));
                                    } else {
                                        $tanggal = date_create()->format('Y:m:d');
                                        $masuk = date_create()->format('H:i:s');
                                        $telat = date_diff(date_create(), date_create($karyawan['jam_masuk']));
                                        $telatt = $telat->format("%H:%i:%s");
                                        mysqli_query($koneksi, "insert into absen values(NULL,'$uid','$tanggal','$masuk','telat','$telatt','$id_mesin')");
                                        http_response_code(201);
                                        echo json_encode(array("message" => "Absen telat berhasil"));
                                    }
                                } else {
                                    $tanggal = date_create()->format('Y:m:d');
                                    $masuk = date_create()->format('H:i:s');
                                    mysqli_query($koneksi, "insert into absen values(NULL,'$uid','$tanggal','$masuk','tepat waktu',NULL,'$id_mesin')");
                                    http_response_code(201);
                                    echo json_encode(array("message" => "Absen tepat waktu berhasil"));
                                }
                            }
                        }
                        } else {
                            $tanggal = date_create()->format('Y:m:d');
                            mysqli_query($koneksi, "insert into absen values(NULL,'$uid','$tanggal',NULL,'cuti',NULL,'$id_mesin')");
                            http_response_code(201);
                            echo json_encode(array("message" => "Anda sedang cuti"));
                        }
                    }
                }
            } else {
                if (mysqli_num_rows($res_penampung) > 0) {
                    mysqli_query($koneksi, "delete from penampung where id_mesin = '$id_mesin'");
                    mysqli_query($koneksi, "insert into penampung values(NULL,'$uid','$id_mesin')");
                    http_response_code(201);
                    echo json_encode(array("message" => "Silahkan Registrasi"));
                } else {
                    mysqli_query($koneksi, "insert into penampung values(NULL,'$uid','$id_mesin')");
                    http_response_code(201);
                    echo json_encode(array("message" => "Silahkan Registrasi"));
                }
            }
        } else {
            http_response_code(404);
            echo json_encode(array("message" => "ID Mesin tidak terdaftar"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Data yang dikirim tidak lengkap"));
    }
}

// Routing berdasarkan metode HTTP
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    handleGETRequest();
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    handlePOSTRequest();
} elseif ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    http_response_code(405);
    echo json_encode(array("message" => "Metode PUT tidak didukung"));
} elseif ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    http_response_code(405);
    echo json_encode(array("message" => "Metode DELETE tidak didukung"));
} else {
    // Metode HTTP tidak didukung
  handleGETRequest();
}
