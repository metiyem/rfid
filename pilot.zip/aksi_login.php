
<?php 
 $link = mysqli_connect('kali.kali', 'root', '', 'rfid'); 


 
$email = $_POST['email'];
$password = md5($_POST['password']);
 
$login = mysqli_query($link,"SELECT user.id,user.nama,user.email,user.password,company.nama_company,company.id FROM user JOIN company on user.id_company = company.id where email='$email' and password='$password'");
$hasil = mysqli_fetch_assoc($login);
$cek = mysqli_num_rows($login);
 
if($cek > 0){
	session_start();
	$_SESSION['nama'] = $hasil['nama'];
	$_SESSION['id'] = $hasil['id'];
    $_SESSION['company'] = $hasil['nama_company'];
	$_SESSION['company_id'] = $hasil['id'];
	$_SESSION['status'] = "login";
	header("location:index.php");
}else{
	header("location:login.php");	
}
if($_SESSION['status'] !== "login"){
	header("location:login.php");
    
}


?>