<?php
require_once "config1.php"; 
$id_mesin=$_POST['id_mesin'];
$id_company=$_POST['id_company'];


$sql = "INSERT INTO mesin_rfid VALUES ('$id_mesin', '$id_company')";
mysqli_query($koneksi,$sql);