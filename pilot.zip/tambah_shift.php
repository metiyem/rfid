<?php

require_once "config1.php";
session_start;
$_SESSION['id'];

        $nama_shift = $_POST['nama_shift'];
        $jam_masuk = $_POST['jam_masuk'];
        $jam_keluar = $_POST['jam_keluar'];
        $libur = $_POST['libur'];
        $toleransi_terlambat = $_POST['toleransi_terlambat'];
        $id_company = intval($_SESSION['id_company']);
        $query = "INSERT INTO shift (nama_shift, jam_masuk, jam_keluar, libur, toleransi_terlambat, id_company) VALUES ('$nama_shift', '$jam_masuk', '$jam_keluar', '$libur', '$toleransi_terlambat', '$id_company')";

mysqli_query($koneksi,$query);