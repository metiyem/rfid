<?php

require_once "config1.php";
 $id = $_POST['id'];
        $query = "DELETE FROM shift WHERE id='$id'";
        mysqli_query($koneksi, $query);