<?php
// add_mesin.php
session_start();
require_once "config1.php"; // Include your DB config file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_mesin = $_POST['id_mesin'];
    $id_company = $_POST['id_company'];

    $query = "INSERT INTO mesin_rfid (id_mesin, id_company) VALUES (?, ?)";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("si", $id_mesin, $id_company);
    $result = $stmt->execute();

    if ($result) {
        echo "Mesin berhasil ditambahkan.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $koneksi->close();
}
?>
