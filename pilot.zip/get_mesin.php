<?php 

$user_id = $_POST['id'];
$sql = "SELECT mesin_rfid.id_mesin, company.nama_company FROM mesin_rfid 
                        JOIN company ON mesin_rfid.id_company = company.id 
                        JOIN user ON company.id = user.id_company 
                        WHERE user.id = '$user_id' 
                        ";


$result = mysqli_query($sql);
$res    = mysqli_fetch_assoc($result);