<?php
require_once "config1.php";
session_start();

if (isset($_GET['id'])) {
    $uid = $_GET['id'];
    $deleteQuery = "DELETE FROM karyawan WHERE uid = ?";
    
    if ($stmt = mysqli_prepare($koneksi, $deleteQuery)) {
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "s", $uid);
        
        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            // Redirect to karyawan.php if deletion was successful
            header("Location: karyawan.php");
            exit();
        } else {
            echo "Error: Could not execute the query: " . mysqli_error($koneksi);
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    } else {
        echo "Error: Could not prepare the query: " . mysqli_error($koneksi);
    }
    
    // Close connection
    mysqli_close($koneksi);
} else {
    // Redirect to karyawan.php if no ID was provided
    header("Location: karyawan.php");
    exit();
}
?>
