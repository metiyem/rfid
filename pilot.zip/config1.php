<?php
    $tgl = date_create()->format("Y:m:d");
    $host = 'kali.kali';
    $user = 'root';
    $pw = '';
    $db = 'rfid';

    $koneksi = mysqli_connect($host, $user, $pw, $db);
    if (!$koneksi) {
        http_response_code(500);
        die(json_encode(array("message" => "Error koneksi ke database")));
    }